import random

#Constant
WORDLIST_1 = ["apple","banana","carrot","durian", "elderberry","fig","grape", "honeydew"]
WORDLIST_2 = ["igloo","jujube","kiwi","lemon","mango","nectarine","orange", "pear"]
WORDLIST_3 = ["quince","raspberry", "strawberry","tangerine","ugli","vanilla","watermelon","xigua" ]

print("PASSWOR GENERATOR")
print("\n")
print("======================")
print("\n")

while True:
    try:
        # Prompt the user to enter thenumber of passwords needed
        num_passwords = int(input ("Enter the number of passwords needed:" ))
        break
    except:
        print("Please enter a numeric value.")
print("\n")
# Check that the number is within the allowed range 
if num_passwords < 1 or num_passwords > 24:
    print("please enter a value between 1 and 24.")
    exit()

else:
# Generate the requested number of passwords
    passwords_list = [ ]
for i in range (num_passwords) :

# Choose three random words from the wordlists
    word1 = random.choice (WORDLIST_1)
    word2 = random.choice (WORDLIST_2)
    word3 =random. choice (WORDLIST_3)

    # Concatenate the words to form a password
    passwords = word1 + word2 + word3
    passwords_list.append (passwords)

count = 1
# Print the generated passwords
for password in passwords_list:
    print('{}--->{}'.format(count, password))
    count +=1



