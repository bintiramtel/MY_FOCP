def to_minutes_seconds(time):
    """Convert time in seconds to minutes and seconds."""
    minutes, seconds = divmod(time, 60)
    return f'{minutes} minutes, {seconds} seconds'

print('Park Run Timer\n~~~~~~~~~~~~~~')
print('\nLet\'s go!\n')


total_runners = 0
total_time = 0
fastest_time = 0
slowest_time = 0
fastest_runner = 0


while True:
    # read a line from the data stream
    line = input('>')

    # check if the line is the end of the stream
    if line == 'END':
        break

    # split the line into runner number and time
    fields = line.split('::')
    if len(fields) != 2:
        # line does not have the correct format, skip it
        continue
    
    # parse the runner number and time
    try:
        runner_number = int(fields[0])
        time = int(fields[1])
    except ValueError:
        print('Error in data stream. Ignoring. Carry')
        # runner number or time is not a valid integer, skip the line
        continue

    # update statistics
    total_runners += 1
    total_time += time
    if time < fastest_time:
        fastest_time = time
        fastest_runner = runner_number
    if time > slowest_time:
        slowest_time = time
    
        

# calculate average time in minutes and seconds
        average_time = total_time / total_runners 
        
        
# print the statistics
print(f'Total number of runners: {total_runners}')
print(f'Average Time:  {to_minutes_seconds(average_time)}')
print(f'Fastest Time:  {to_minutes_seconds(fastest_time)}')
print(f'Slowest Time:  {to_minutes_seconds(slowest_time)}')
print(f'Runner with fastest time: {fastest_runner}')
